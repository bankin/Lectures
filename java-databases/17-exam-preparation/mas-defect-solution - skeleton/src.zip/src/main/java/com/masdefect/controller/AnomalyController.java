package com.masdefect.controller;

import org.springframework.stereotype.Controller;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@Controller
public class AnomalyController {

    public String importDataFromJSON(String fileContent) {
        //impl
        return null;
    }

    public String importDataFromXML(String fileContent) {
        //impl
        return null;
    }

    public String findAnomalyWithMostVictims() {
       return null;
    }

    public String exportAnomaliesOrdered() {
        return null;
    }
}
