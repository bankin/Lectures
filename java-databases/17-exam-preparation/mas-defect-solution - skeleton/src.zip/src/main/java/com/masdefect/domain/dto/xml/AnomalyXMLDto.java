package com.masdefect.domain.dto.xml;

public class AnomalyXMLDto {
    //impl
}
