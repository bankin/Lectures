package com.masdefect.domain.dto.json;

import java.io.Serializable;

public class AnomalyVictimsJSONDto implements Serializable {
    //impl
}
