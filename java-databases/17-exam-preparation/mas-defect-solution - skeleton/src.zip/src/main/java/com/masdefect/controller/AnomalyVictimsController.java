package com.masdefect.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AnomalyVictimsController {

    public String importDataFromJSON(String fileContent){
        //impl
        return null;
    }
}
