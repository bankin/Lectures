package com.masdefect.domain.dto.xml;

public class AnomaliesXMLDto {
    //impl
}
